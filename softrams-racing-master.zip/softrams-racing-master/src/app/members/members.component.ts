import { Component, OnInit } from '@angular/core';
import { AppService } from '../app.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-members',
  templateUrl: './members.component.html',
  styleUrls: ['./members.component.css']
})
export class MembersComponent implements OnInit {
  members = [];
  teams = [];
  constructor(public appService: AppService, private router: Router) {}

  ngOnInit() {
    this.appService.getMembers().subscribe(members => (this.members = members));
    this.appService.getTeams().subscribe(teams => (this.teams = teams));
  }

  goToAddMemberForm() {
   this.router.navigate(['/members-details']);
  }

  editMemberByID(id: number) {
    this.router.navigate(['/members-details',id]);
  }

  deleteMemberById(id: number) {
    this.appService.deleteMembers(id).subscribe(response => {if(response!=undefined){
      this.appService.getMembers().subscribe(members => (this.members = members));
    }});
  }
}
