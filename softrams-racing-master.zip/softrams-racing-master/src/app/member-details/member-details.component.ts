import { Component, OnInit, OnChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppService } from '../app.service';
import { Router, ActivatedRoute } from '@angular/router';

// This interface may be useful in the times ahead...
interface Member {
  firstName: string;
  lastName: string;
  jobTitle: string;
  team: string;
  status: string;
}

@Component({
  selector: 'app-member-details',
  templateUrl: './member-details.component.html',
  styleUrls: ['./member-details.component.css']
})
export class MemberDetailsComponent implements OnInit, OnChanges {
  memberModel: Member;
  memberForm: FormGroup;
  submitted = false;
  alertType: String;
  alertMessage: String;
  teams = [];
  routeId:any;
  members = [];
  members1 = [];

  constructor(private fb: FormBuilder, private appService: AppService, private router: Router,private route: ActivatedRoute) {
    this.memberForm =this.fb.group({
      firstName: ['',[Validators.required]],
      lastName: ['',[Validators.required]],
      team: ['',[Validators.required]],
      jobTitle: ['',[Validators.required]],
      status: ['',[Validators.required]],
    });
  }

  ngOnInit() {
    this.appService.getTeams().subscribe(teams => {this.teams = teams; console.log(this.teams)});
    this.appService.getMembers().subscribe(members => {this.members = members;
      this.route.paramMap.subscribe(params => {
        console.log(params.get('id'));
        this.routeId = params.get('id');
        console.log(this.members);
        this.members1 = this.members.filter(
          member => member.id == this.routeId);
      
        });
        this.memberForm.controls['firstName'].setValue(this.members1[0].firstName);
        this.memberForm.controls['lastName'].setValue(this.members1[0].lastName);
        this.memberForm.controls['team'].setValue(this.members1[0].team);
        this.memberForm.controls['jobTitle'].setValue(this.members1[0].jobTitle);
        this.memberForm.controls['status'].setValue(this.members1[0].status);
    });
    

     
  }

  get f() { return this.memberForm.controls; }

  ngOnChanges() {}

  // TODO: Add member to members
  onSubmit(form: FormGroup) {
    this.submitted = true;
    if (this.memberForm.invalid) {
      return;
  }
     this.memberModel = form.value;
     if( this.routeId==undefined){
      this.appService.addMember(this.memberModel
        ).subscribe(response => {
          if(response.firstName!==undefined){
           this.router.navigate(['/members']);
        }});
     }else{
      this.appService.putMember({params:{data:this.memberModel,id:this.routeId}}
        ).subscribe(response => {
          if(response.firstName!==undefined){
           this.router.navigate(['/members']);
        }});
     }
   
  }
}
